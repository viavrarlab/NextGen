
EN   Your CAD data on 12.12.2019 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 552706 ERMB-20 
    
    ACAD3D, 552706 ERMB-20, 552706_ERMB-20.dwg
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    
